// TYTEN PEREZ - CS-305 - MODULE 7-2 - 08-15-24
package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;

@SpringBootApplication
public class SslServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

@RestController
class ServerController {

    @RequestMapping("/hash")
    public String myHash() {
    	
    	// TYTEN PEREZ - MODULE 7
        String artemisFile = "[artemis file to be verified]";
        String algorithm = "SHA-256";
        
        try {
            // Create MessageDigest instance for SHA-256
            MessageDigest md = MessageDigest.getInstance(algorithm);
            
            md.update(artemisFile.getBytes());
            
            byte[] bytes = md.digest();
            StringBuilder sb = new StringBuilder();
            
            for (int i = 0; i < bytes.length; i++) {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            // output for browser
            return String.format("<p>Artemis file: %s</p><p>Name of Cipher Algorithm Used: %s</p><p>File's CheckSum Value: %s</p>", 
                                 artemisFile, algorithm, sb.toString());
        } catch (NoSuchAlgorithmException e) {
            // Log instead of displaying entire exception to user which
        	// could inadvertently leak sensitive server information:
            Logger.getLogger(ServerController.class.getName()).log(Level.SEVERE, null, e);
            // Return a generic error message to user
            return "<p>An error occurred while processing your request.</p>";
        }
    }
}